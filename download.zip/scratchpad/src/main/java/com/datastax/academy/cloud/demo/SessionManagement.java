package com.datastax.academy.cloud.demo;

import java.io.File;

import com.datastax.dse.driver.api.core.DseSession;

public class SessionManagement {
  static DseSession session;
  public static void initSession() throws Exception {
    session = DseSession.builder().forClusterConfig("/projects/creds").build();
  }
  public static DseSession getSession() {
    return session;
  }
  public static void closeSession() {
      session.close();
  }
}
