package com.datastax.academy.cloud.demo;

import java.time.Instant;
import java.util.UUID;

public class User {

    private UUID userid;
    private String firstname;
    private String lastname;
    private String email;
    private Instant createdAt;

    public User() {}

    public User(UUID userid, String firstname, String lastname, String email, Instant createdAt) {
        this.userid = userid;
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.createdAt = createdAt;
    }
    public UUID getUserid() {
        return userid;
    }
    public void setUserid(UUID userid) {
        this.userid = userid;
    }
    public String getFirstname() {
        return firstname;
    }
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }
    public String getLastname() {
        return lastname;
    }
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public Instant getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
