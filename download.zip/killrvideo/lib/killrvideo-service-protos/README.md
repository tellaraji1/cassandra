# KillrVideo Service Definitions

The definitions for the services used in KillrVideo, defined using 
[Google's Protocol Buffers](https://developers.google.com/protocol-buffers/). This project can be used
along with [grpc](https://github.com/grpc/grpc) to generate client and server code in multiple 
programming languages, allowing the KillrVideo backend services to be implemented in those languages.