package killrvideo.configuration;


import org.springframework.context.annotation.Configuration;

/**
 * Setting up mapping between entities and Cassandra UDT.
 * 
 * @author DataStax evangelist team.
 */
@Configuration
public class DseMapperConfiguration {

}
