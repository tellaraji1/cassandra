package killrvideo.dataLayer;

import java.io.File;
import java.util.UUID;
import java.time.Instant;

import com.datastax.oss.driver.api.core.cql.BatchStatement;
import com.datastax.oss.driver.api.core.cql.BoundStatement;
import com.datastax.oss.driver.api.core.cql.DefaultBatchType;
import com.datastax.oss.driver.api.core.cql.PreparedStatement;
import com.datastax.oss.driver.api.core.cql.ResultSet;
import com.datastax.oss.driver.api.core.cql.Row;
import com.datastax.oss.driver.api.core.cql.SimpleStatement;
import com.datastax.oss.driver.api.core.cql.SimpleStatementBuilder;
import com.datastax.dse.driver.api.core.DseSession;
import com.datastax.oss.driver.api.core.DefaultConsistencyLevel;
import com.datastax.oss.driver.api.querybuilder.QueryBuilder;
import com.datastax.oss.driver.api.querybuilder.insert.RegularInsert;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import killrvideo.entity.User;

public class UserAccess {

  private static final Logger LOGGER = LoggerFactory.getLogger(UserAccess.class);
  
  public static boolean createNewUser(DseSession session, 
    String password, User user) throws Exception {
    LOGGER.debug("------Start createNewUser------");
    return false;
  }

  public static UUID getAuthenticatedIdByEmailPassword(DseSession session,
    String email, String password) throws Exception {
    LOGGER.debug("------Start getAuthenticatedIdByEmailPassword------");

    //-----------------------------------------------------------------------------
	// Create a string to SELECT the user from user_credentials based on email
	// TBD: Create the SELECT command string that selects from user_credentials:
    //-----------------------------------------------------------------------------
	String command = "SELECT * FROM killrvideo.user_credentials WHERE email = ?"; 
    // Create the SimpleStatement that combines the command with the email:
    SimpleStatement statement = SimpleStatement.newInstance(command, email);
	// Execute the statement and get the result set
	ResultSet meResultSet = session.execute(statement);
	// Get the row from the result set
	Row meRow = meResultSet.one();
	// Create a UUID for the returned user ID and initialize it to null
	UUID userId = null;
	// If the row exists,
	if (meRow != null) {
		// Get the password value from the row
		String passwordFromDB = meRow.getString("password");
		// If the password value from the row equals password parameter,
		if (password.equals(passwordFromDB)) {
			// Set the returned user ID to the row’s user ID
			userId = meRow.getUuid("userid");
		}
	}

	// Return the user ID
	return userId;
  }
  public static User getUserById(DseSession session, 
    UUID userid) throws Exception {
    LOGGER.debug("------Start getUserById------");
    return null;
  }
}